void check_for_host_flapping(host *hst, int update, int actual_check, int allow_flapstart_notification) 
{ }

void check_for_service_flapping(service *svc, int update, int allow_flapstart_notification) 
{ }

void disable_service_flap_detection(service *svc) 
{ }

void disable_host_flap_detection(host *hst) 
{ }

void disable_flap_detection_routines(void) 
{ }

void enable_flap_detection_routines(void) 
{ }

void enable_service_flap_detection(service *svc) 
{ }

void enable_host_flap_detection(host *hst) 
{ }
